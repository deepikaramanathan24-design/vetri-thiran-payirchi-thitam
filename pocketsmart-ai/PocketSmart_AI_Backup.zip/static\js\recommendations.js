function showResult(data) {
    const result = document.getElementById("result");
    const text = data.ai_recommendations || data.recommendations || "";

    result.innerHTML = `
        <h3>${data.message}</h3>
        <pre>${text}</pre>
    `;
}

async function sendRequest(url, data) {
    const response = await fetch(url, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    });

    return await response.json();
}

const homeForm = document.getElementById("homeForm");

if (homeForm) {
    homeForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const data = {
            user_id: Number(document.getElementById("user_id").value),
            budget: Number(document.getElementById("budget").value),
            room: document.getElementById("room").value,
            style: document.getElementById("style").value
        };

        showResult(await sendRequest("/generate-home", data));
    });
}

const partyForm = document.getElementById("partyForm");

if (partyForm) {
    partyForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const data = {
            user_id: Number(document.getElementById("user_id").value),
            budget: Number(document.getElementById("budget").value),
            event_type: document.getElementById("event_type").value,
            guests: Number(document.getElementById("guests").value),
            theme: document.getElementById("theme").value
        };

        showResult(await sendRequest("/generate-party", data));
    });
}

const jewelryForm = document.getElementById("jewelryForm");

if (jewelryForm) {
    jewelryForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const data = {
            user_id: Number(document.getElementById("user_id").value),
            budget: Number(document.getElementById("budget").value),
            jewelry_type: document.getElementById("jewelry_type").value,
            occasion: document.getElementById("occasion").value,
            style: document.getElementById("style").value
        };

        showResult(await sendRequest("/generate-jewelry", data));
    });
}
